import 'package:get_storage/get_storage.dart';
var box = GetStorage();
String get currentUserName => box.read("username") ?? "Jane Doe";