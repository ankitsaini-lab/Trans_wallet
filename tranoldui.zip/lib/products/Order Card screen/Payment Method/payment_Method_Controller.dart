import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:transwallet/products/Order%20Card%20screen/order%20card%20screen/ordercard_Controller.dart';
import 'package:transwallet/products/Order%20Card%20screen/Review%20order%20Details/review_order_details_Controller.dart';
import 'package:transwallet/products/Wallet%20Screen/Add%20Money/addmoney_Controller.dart';
import 'package:transwallet/products/Send%20money%20screen/send%20money%20process/sendmoneyProcess_Controller.dart';
import 'package:transwallet/utilities/getStorage.dart';

class PaymentMethodController extends GetxController {
  final RxInt selectedMethod = 1.obs; 
  var walletBalance = 640.obs;
  var amount = 150.obs;

  
  var cardGradient = <Color>[const Color(0xFF111111), const Color(0xFF2C2C2C)].obs;
  var cardStyleName = "Obsidian Black".obs;
  
  
  var deliveryAddress = "General Address".obs;
  var receiverName = "".obs;

  @override
  void onInit() {
    super.onInit();
    
    if (Get.isRegistered<OrdercardController>()) {
      final orderCtrl = Get.find<OrdercardController>();
      final activeStyle = orderCtrl.cardStyles[orderCtrl.activeCardIndex.value];
      cardGradient.assignAll(activeStyle["colors"]);
      cardStyleName.value = activeStyle["name"];
      amount.value = orderCtrl.amount.value;
    }
    receiverName.value = currentUserName;
    if (Get.isRegistered<ReviewOrderDetailsController>()) {
      final reviewCtrl = Get.find<ReviewOrderDetailsController>();
      receiverName.value = reviewCtrl.name.value.isEmpty ? currentUserName : reviewCtrl.name.value;
      deliveryAddress.value = reviewCtrl.address1.value.isEmpty
          ? "General Address"
          : "${reviewCtrl.address1.value}, ${reviewCtrl.city.value}, ${reviewCtrl.state.value} - ${reviewCtrl.pincode.value}";
    }
  }

  void processPayment() {
    
    if (selectedMethod.value == 1 && walletBalance.value < amount.value) {
      Get.snackbar(
        "Insufficient Balance",
        "Your wallet has ₹${walletBalance.value}. Please add ₹${amount.value - walletBalance.value} more to proceed.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: const Color(0xFF111111),
        colorText: Colors.white,
        borderRadius: 16,
        margin: const EdgeInsets.all(16),
      );
      return;
    }

    
    Get.bottomSheet(
      MpinVerifySheetForPayment(
        onSuccess: () => _executePayment(),
        title: "Verify MPIN to Order Card",
        subtitle: "Enter MPIN to authorize ₹${amount.value}.00 from General Wallet",
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
    );
  }

  void _executePayment() async {
    
    Get.to(() => const PaymentProcessingScreen());

    await Future.delayed(const Duration(seconds: 2));
    
    if (selectedMethod.value == 1) {
      walletBalance.value -= amount.value;
    }

    
    Get.offAllNamed('/orderdetails', arguments: {
      'amount': amount.value,
      'cardGradient': cardGradient,
      'cardStyleName': cardStyleName.value,
      'receiverName': receiverName.value,
      'deliveryAddress': deliveryAddress.value,
    });
  }
}